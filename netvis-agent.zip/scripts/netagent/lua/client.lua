--
-- Copyright (c) 2015 AppDynamics Inc.
-- All rights reserved.
--
-- $Id$

-- setup lua-zmq client
-- local connect_to
-- local message_size

local zmq = require"zmq"

npm_zmq = {}

function npm_zmq.init(t)
	npm_zmq.ctx = zmq.init(1)
	npm_zmq.so = assert(ctx:socket(zmq.PUSH))
	assert(npm_zmq.so:bind(bind_to))
end

function npm_zmq.fini(t)
	npm_zmq.so:close()
	npm_zmq.ctx.term()
end

function npm_zmq.send(t)
	local data = ("0"):rep(message_size)
	local msg = zmq.zmq_msg_t.init_size(message_size)
	assert(s:send_msg(msg))
end

function npm_zmq.recv(t)
	assert(s:send_msg(msg))
end




