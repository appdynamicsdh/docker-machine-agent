--
-- Copyright (c) 2015 AppDynamics Inc.
-- All rights reserved.
--
-- $Id$

local ffi = require("ffi")
local agentComm = require "comm/encap/agent_comm_capnp"
local zmq = require "scripts/lua/client"

-- serialize the data
function npmSerialize (r, l, t, fr, rto, ss)
	local data = {
		rtt = r,
		tput = t,
		loss = l
	}
	local bin = agentComm.Metric.serialize(data)
	if not zmq.ctx then
		zmq.connect()
	end

	zmq.send(bin)
--	local decoded = agentComm.Metric.parse(bin)
--	print(decoded.rtt)
end

function npmnewSerialize()
	local bin = agentComm.FlowStats.serialize(nflowstats)
	if not zmq.ctx then
		zmq.connect()
	end

	zmq.send(bin)
end

function print_r ( t )  
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end
    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t,"  ")
        print("}")
    else
        sub_print_r(t,"  ")
    end
    print()
end
