--[[
 * Copyright (c) AppDynamics, Inc., and its affiliates
 * 2015
 * All Rights Reserved
 * THIS IS UNPUBLISHED PROPRIETARY CODE OF APPDYNAMICS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code
--]]

plugins = {
	{file_name = "socket.lua"},
	{file_name = "process.lua"},
	{file_name = "all-interface.lua"},
--	{file_name = "interface.lua"},
--	{file_name = "tcp.lua"},
--	{file_name = "icmp.lua"},
--	{file_name = "cpu-load.lua"},
--	{file_name = "memory.lua"},
}
