require "helper"

function test_get_column_value_snmp_format()
	local v
	local str = [[
TcpExt: SyncookiesSent SyncookiesRecv SyncookiesFailed EmbryonicRsts PruneCalled RcvPruned OfoPruned OutOfWindowIcmps LockDroppedIcmps ArpFilter TW TWRecycled TWKilled PAWSPassive PAWSActive PAWSEstab DelayedACKs DelayedACKLocked DelayedACKLost ListenOverflows ListenDrops TCPPrequeued TCPDirectCopyFromBacklog TCPDirectCopyFromPrequeue TCPPrequeueDropped TCPHPHits TCPHPHitsToUser TCPPureAcks TCPHPAcks TCPRenoRecovery TCPSackRecovery TCPSACKReneging TCPFACKReorder TCPSACKReorder TCPRenoReorder TCPTSReorder TCPFullUndo TCPPartialUndo TCPDSACKUndo TCPLossUndo TCPLostRetransmit TCPRenoFailures TCPSackFailures TCPLossFailures TCPFastRetrans TCPForwardRetrans TCPSlowStartRetrans TCPTimeouts TCPLossProbes TCPLossProbeRecovery TCPRenoRecoveryFail TCPSackRecoveryFail TCPSchedulerFailed TCPRcvCollapsed TCPDSACKOldSent TCPDSACKOfoSent TCPDSACKRecv TCPDSACKOfoRecv TCPAbortOnData TCPAbortOnClose TCPAbortOnMemory TCPAbortOnTimeout TCPAbortOnLinger TCPAbortFailed TCPMemoryPressures TCPSACKDiscard TCPDSACKIgnoredOld TCPDSACKIgnoredNoUndo TCPSpuriousRTOs TCPMD5NotFound TCPMD5Unexpected TCPSackShifted TCPSackMerged TCPSackShiftFallback TCPBacklogDrop TCPMinTTLDrop TCPDeferAcceptDrop IPReversePathFilter TCPTimeWaitOverflow TCPReqQFullDoCookies TCPReqQFullDrop TCPRetransFail TCPRcvCoalesce TCPOFOQueue TCPOFODrop TCPOFOMerge TCPChallengeACK TCPSYNChallenge TCPFastOpenActive TCPFastOpenActiveFail TCPFastOpenPassive TCPFastOpenPassiveFail TCPFastOpenListenOverflow TCPFastOpenCookieReqd TCPSpuriousRtxHostQueues BusyPollRxPackets TCPAutoCorking TCPFromZeroWindowAdv TCPToZeroWindowAdv TCPWantZeroWindowAdv TCPSynRetrans TCPOrigDataSent
TcpExt: 0 0 0 0 0 0 0 0 0 0 28 0 0 0 0 0 45 0 0 0 0 0 0 0 0 6225 0 319 459 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1585 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 611
IpExt: InNoRoutes InTruncatedPkts InMcastPkts OutMcastPkts InBcastPkts OutBcastPkts InOctets OutOctets InMcastOctets OutMcastOctets InBcastOctets OutBcastOctets InCsumErrors InNoECTPkts InECT1Pkts InECT0Pkts InCEPkts
IpExt: 0 0 126 144 0 0 14877221 607541 19007 19727 0 0 0 19226 0 0 0
]]

	v = get_column_value_snmp_format(str, "TcpExt", "TW")
	dump(v)
	v = get_column_value_snmp_format(str, "TcpExt", "TCPHPHitsToUser")
	dump(v)
	v = get_column_value_snmp_format(str, "TcpExt", "TCPHPHits")
	dump(v)
	v = get_column_value_snmp_format(str, "TcpExt", "TCPPureAcks")
	dump(v)
end

function test_escape_magic_chars()
	local string = "TX-OVR"
	local new_str = escape_magic_chars(string, g_magic_chars)
	dump(new_str)
end

function test_merge_table()
	local _t1 = {["a"] = 1, ["b"] = 2}
	local _t2 = {["c"] = 3, ["d"] = 4}

	local _t3 = merge_table(_t1, _t2)
	dump(_t3)
end

function test_merge_table_2()
	local _t1 = {
		{a = 1},
		{b = 2},
		{c = 3},
	}
	local _t2 = {
		{d = 4},
		{e = 5},
		{f = 6},
	}

	local _t3 = merge_table_2(_t1, _t2)
	dump(_t3)
	dump(_t1)
	dump(_t2)
end


-- Function to test get_column_value api with the
-- row selector set to nil
function test_get_column_value()
	local v
	local str = [[
%CPU %MEM   PID CMD
0.8 10.6 13693 appd-netagent -l /opt/appdynamics/netviz/scripts/netagent/lua/
]]
	v = get_column_value(str, "appd-netagent", "%CPU")
	dump(v)
	v = get_column_value(str, "appd-netagent", "%MEM")
	dump(v)
	--v = get_column_value(str, nil, "MEM")
	--dump(v)
end

function test_get_pattern_count()
	local str = [[
State      Recv-Q Send-Q        Local Address:Port          Peer Address:Port
CLOSE-WAIT 1      0                 10.0.2.15:41073        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:54976        162.213.33.48:443
CLOSE-WAIT 1      0                 10.0.2.15:41057        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:54958        162.213.33.48:443
CLOSE-WAIT 1      0                 10.0.2.15:41048        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:41077        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:58877        162.213.33.50:443
CLOSE-WAIT 1      0                 10.0.2.15:41054        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:54996        162.213.33.48:443
CLOSE-WAIT 1      0                 10.0.2.15:41042        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:58836        162.213.33.50:443
ESTAB      0      0                 10.0.2.15:53494           10.0.73.65:22
CLOSE-WAIT 1      0                 10.0.2.15:41063        162.213.33.49:443
CLOSE-WAIT 1      0                 10.0.2.15:54993        162.213.33.48:443
ESTAB      0      0                 127.0.0.1:59688            127.0.0.1:22
CLOSE-WAIT 1      0                 10.0.2.15:54990        162.213.33.48:443
CLOSE-WAIT 1      0                 10.0.2.15:58874        162.213.33.50:443
CLOSE-WAIT 1      0                 10.0.2.15:58861        162.213.33.50:443
ESTAB      0      68                127.0.0.1:22               127.0.0.1:59688
CLOSE-WAIT 1      0                 10.0.2.15:58839        162.213.33.50:443
CLOSE-WAIT 1      0                 10.0.2.15:54955        162.213.33.48:443
CLOSE-WAIT 1      0                 10.0.2.15:58842        162.213.33.50:443
CLOSE-WAIT 1      0                       ::1:49402                  ::1:631
]]
	local count = get_pattern_count(str, "CLOSE-WAIT")
	dump(count)
end

--test_get_column_value_snmp_format()
--test_escape_magic_chars()
--test_merge_table()
--test_merge_table_2()
--test_get_column_value()
--test_get_pattern_count()
