--
-- Copyright (c) 2015 AppDynamics Inc.
-- All rights reserved.
--
-- $Id$

-- Statistics related functions

stats = {}
-- get the max and min for a table
function stats.maxmin(t)
	local max = -math.huge
	local min = math.huge

function variance(t)
	local 

-- mean average of a table
function stats.mean(t)
	local sum = 0
	local count = 0

	for k, v in pairs(t) do
		if type(v) == 'number' then
			sum = sum + v
			count = count + 1
		end
	end

	return (sum / count)
end

