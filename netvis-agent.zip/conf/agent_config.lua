--
-- Copyright (c) 2015 AppDynamics Inc.
-- All rights reserved.
--
-- $Id$

ROOT_DIR="/opt/appdynamics/netviz"
RUN_DIR=ROOT_DIR .. "/run/"
INSTALL_DIR=ROOT_DIR
-- Define a unique hostname for identification on controller
UNIQUE_HOST_ID = ""

--
-- NPM global configuration
-- Configurable params
-- {
--	enable_monitor = 0/1,	-- def:0, enable/disable monitoring
--	disable_filter = 0/1,	-- def:0, disable/enable language agent filtering
--	mode = KPI/Diagnostic/Advanced,	-- def:KPI
--	enable_netlib = 0/1,	-- def:0, using netlib to map appid with tuples.
--	lua_scripts_path	-- Path to lua scripts.
-- }
--
npm_config = {
	log_destination = "file",
	log_file = "appd-netagent.log",
	debug_log_file = "agent-debug.log",
	disable_filter = 1,
	mode = "KPI",
	enable_netlib = 0,
	lua_scripts_path = ROOT_DIR .. "/scripts/netagent/lua/",
}

--
-- Webserver configuration
-- Configurable params
-- {
--	port = ,		-- Port on which to open the webserver
--	request_timeout = , -- Request timeout in ms
--	threads = ,		-- Number of threads on the webserver
-- }
--
webserver_config = {
	port = 3892,
	request_timeout = 10000,
	threads = 2,
}

--
-- Packet capture configurations (multiple captures can be configured)
-- Confiurable params, there can be multiple of these.
-- {
-- 	cap_module = "pcap",		-- def:"pcap", capture module
-- 	cap_type = "device"/"file",	-- def:"device", type of capture
-- 	ifname = "",		-- def:"any", interface name/pcap filename
-- 	enable_promisc = 0/1,	-- def:0, promiscuous mode pkt capture
-- 	thinktime = ,		-- def: 100, time in msec, to sleep if no pkts
-- 	snaplen = ,		-- def:1518. pkt capture len
-- 	buflen = ,		-- def:2. pcap buffer size in MB
-- 	ppi = ,			-- def:32. pcap ppi
-- },
--
capture = {
	-- first capture interface
	{
		cap_module = "pcap",
		cap_type = "device",
		ifname = "any",
		thinktime = 25,
		buflen = 48,
--		filter = "",
	},
--[[	{
		cap_module = "pcap",
		cap_type = "device",
		ifname = "en0",
	},
--]]
}

--
-- Export data from network agent configuration/tunnables
-- Configurable params, there can be multiple of these.
-- {
-- 	exportype = "file"/"remote",	-- type of export mechanism
-- 	statsfile = "",			-- filename for stats export
-- 	metricsfile = "", 		-- filename for metrics export
-- 	serialization = "pb",		-- pb/capnp, serialization module
-- 	transport = "zmq", 		-- def:"zmq", transport module
-- 	zmqdest = "", 			-- dest peer for zmq
--  },
--
export_config = {
	-- file export
	{
		exporttype = "file",
		statsfile = "agent-stats.log",
		metricsfile = "agent-metrics.log",
		eventsfile =  "agent-events.log",
		snapshotsfile = "agent-snapshots.log",
	},
}

-- Plugin interface configuration.
-- List of interfaces to be monitored by supported plugins.
-- Configurable params, there can be multiple of these.
-- {
-- 	interface = "eth0",	-- def: "eth0", interface name
-- }
plugin_if_config = {
--[[
	{interface = "eth0"},
--]]
}

-- Plugin process configuration.
-- List of processes to be monitored by supported plugins.
-- Configurable params, there can be multiple of these.
-- {
--	process = "",		-- def: "appd-netagent", process name
-- }
plugin_proc_config = {
	{process = "appd-netagent"},
}

-- metadata to pass to pass the agent metadata specific params
function os.capture(cmd, raw)
	local f = assert(io.popen(cmd, 'r'))
	local s = assert(f:read('*all'))
	f:close()
	if raw then return s end
	s = string.gsub(s, '^%s+', '')
	s = string.gsub(s, '%s+$', '')
	s = string.gsub(s, '[\n\r]+', ' ')
	return s
end
OS_NAME =  os.capture("uname -s", false)
HOST_NAME = os.capture("uname -n", false)

function get_last_update_time()
	local curr_dir = os.capture("pwd", false)
	local stat_fmt = "-c %Y"
	if (OS_NAME == "Darwin") then
		stat_fmt = "-f %B"
	end
	local stat_cmd = "stat " .. stat_fmt .. " \"" .. curr_dir .. "\""
	local  time_update = os.capture(stat_cmd, false)
	epoch_time_update = tonumber(time_update)
	return epoch_time_update
end

-- get unique host id of the machine
function getuniquehostid()
	if (UNIQUE_HOST_ID == "") then
		UNIQUE_HOST_ID = HOST_NAME
	end
	return UNIQUE_HOST_ID
end

system_metadata = {
	unique_host_id = getuniquehostid(),
	hostname = HOST_NAME,
	os_name = OS_NAME,
	os_version = os.capture("uname -r", false),
	install_dir = INSTALL_DIR,
	install_time = get_last_update_time(),
}
